//
//  Label.swift
//  Game-Starter-Empty
//
//  Created by Ricardo Rodriguez on 10/2/18.
//  Copyright © 2018 Make School. All rights reserved.
//

import SpriteKit


class Label: SKLabelNode {
    var Score = 0
   // var scoreLabel = SKLabelNode(fontNamed: "Chalkduster")
    
    override init(fontNamed: String?) {
        
        super.init()
        
        self.fontSize = 20
        self.fontColor = .white
        self.name = "ScoreLabel"
        self.text = "Score: 0"
        
    }
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}
